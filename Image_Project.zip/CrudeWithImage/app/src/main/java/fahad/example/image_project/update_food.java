package fahad.example.image_project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class update_food extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_food);
    }
}
